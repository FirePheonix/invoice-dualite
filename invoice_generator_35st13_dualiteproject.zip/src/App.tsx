import { useState, useRef, useEffect } from 'react';
import { InvoiceData } from './types/invoice';
import { initialInvoiceData } from './data/initialData';
import InvoiceForm from './components/InvoiceForm';
import InvoicePreview from './components/InvoicePreview';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Download } from 'lucide-react';

function App() {
  const [invoiceData, setInvoiceData] = useState<InvoiceData>(initialInvoiceData);
  const invoicePreviewRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  // This effect recalculates totals whenever the source data changes.
  useEffect(() => {
    const updatedItems = invoiceData.items.map(item => ({
      ...item,
      amount: item.qty * item.rate,
    }));

    const grossAmount = updatedItems.reduce((sum, item) => sum + item.amount, 0);
    const total = grossAmount; // Assuming no taxes for now

    // Use a functional update to avoid stale state, but check for actual changes
    // to prevent infinite loops.
    setInvoiceData(prev => {
      const needsUpdate = JSON.stringify(prev.items) !== JSON.stringify(updatedItems) ||
                          prev.summary.grossAmount !== grossAmount ||
                          prev.summary.total !== total;
      if (needsUpdate) {
        return {
          ...prev,
          items: updatedItems,
          summary: {
            ...prev.summary,
            grossAmount,
            total,
          },
        };
      }
      return prev;
    });
  }, [invoiceData.items]);


  const handleDataChange = (updateFn: (prev: InvoiceData) => InvoiceData) => {
    setInvoiceData(prevData => {
      const newData = updateFn(prevData);

      const updatedItems = newData.items.map(item => ({
        ...item,
        amount: item.qty * item.rate
      }));

      const grossAmount = updatedItems.reduce((sum, item) => sum + item.amount, 0);
      const total = grossAmount;

      return {
        ...newData,
        items: updatedItems,
        summary: {
          ...newData.summary,
          grossAmount,
          total,
        }
      };
    });
  };

  const handleDownloadPdf = async () => {
    const invoiceContainer = invoicePreviewRef.current;
    if (!invoiceContainer) return;

    setIsDownloading(true);
    document.body.classList.add('print-friendly');

    const pageElements = invoiceContainer.querySelectorAll('.A4-page');
    if (pageElements.length === 0) {
        console.error("No pages found to print.");
        setIsDownloading(false);
        return;
    }

    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    for (let i = 0; i < pageElements.length; i++) {
        const pageElement = pageElements[i] as HTMLElement;
        const canvas = await html2canvas(pageElement, {
            scale: 3,
            useCORS: true,
            width: pageElement.offsetWidth,
            height: pageElement.offsetHeight,
        });
        const imgData = canvas.toDataURL('image/png');
        
        if (i > 0) {
            pdf.addPage();
        }
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    }

    document.body.classList.remove('print-friendly');
    pdf.save(`invoice-${invoiceData.invoice.number}.pdf`);
    setIsDownloading(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-800">
      <header className="bg-white shadow-sm sticky top-0 z-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Invoice Generator</h1>
          <button
            onClick={handleDownloadPdf}
            disabled={isDownloading}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            <Download size={18} />
            {isDownloading ? 'Downloading...' : 'Download PDF'}
          </button>
        </div>
      </header>
      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2">
            <InvoiceForm invoiceData={invoiceData} onDataChange={handleDataChange} />
          </div>
          <div className="lg:col-span-3">
             <div className="sticky top-24">
                <InvoicePreview ref={invoicePreviewRef} invoiceData={invoiceData} />
             </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
