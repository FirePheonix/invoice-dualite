import React from 'react';
import { InvoiceData, InvoiceItem } from '../types/invoice';

interface InvoicePageProps {
  invoiceData: InvoiceData;
  items: InvoiceItem[];
  pageNumber: number;
  totalPages: number;
}

const InvoicePage: React.FC<InvoicePageProps> = ({ invoiceData, items, pageNumber, totalPages }) => {
  const { company, invoice, buyer, summary, bankDetails, declaration, signatory } = invoiceData;

  const isFirstPage = pageNumber === 1;
  const isLastPage = pageNumber === totalPages;

  return (
    <div className="A4-page bg-white p-8 shadow-lg font-montserrat flex flex-col">
      <div className="relative text-xxs leading-tight h-full flex flex-col">
        {isFirstPage && (
          <>
            {/* Header */}
            <div className="flex justify-between items-start mb-8">
              <div className="flex items-start">
                <img src={company.logoUrl} alt="Company Logo" className="h-16 w-16 mr-4 object-contain" />
                <div>
                  <p className="font-bold text-xxs">{company.name}</p>
                  <p className="w-40">{company.address}</p>
                  <p className="w-48">{company.location}</p>
                  <br />
                  <p>GSTIN/UIN: {company.gstin}</p>
                  <p>{company.state}</p>
                  <p>CIN: {company.cin}</p>
                  <p>E-Mail : {company.email}</p>
                  <p>Company's PAN/IEC: {company.pan}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-normal">Invoice No.</p>
                <p className="font-bold mb-2">{invoice.number}</p>
                <p className="font-normal">Dated</p>
                <p className="font-bold mb-2">{invoice.date}</p>
                <p className="font-normal">Mode/Terms of Payment</p>
                <p className="font-bold mb-2">{invoice.modeOfPayment}</p>
                <p className="font-normal">Reference No. and Date</p>
                <p className="font-bold">{invoice.reference}/{invoice.referenceDate}</p>
              </div>
            </div>

            {/* Buyer Info */}
            <div className="mb-4">
              <p>Buyer (Bill to)</p>
              <p className="font-bold">{buyer.name}</p>
              <p className="font-bold">{buyer.address}</p>
              <p className="font-bold">{buyer.country}</p>
              <p className="font-bold">State:{buyer.state} , Code: {buyer.stateCode}</p>
              <p className="text-invoice-blue font-bold">{buyer.email}</p>
              <p className="text-invoice-blue font-bold">{buyer.id}</p>
            </div>
          </>
        )}
        
        {!isFirstPage && (
            <div className="h-48"> {/* Placeholder for header space on subsequent pages */}
                <p className="text-right font-bold">Invoice No. {invoice.number} (Cont.)</p>
            </div>
        )}

        {/* Items Table */}
        <div className="border-t border-black flex-grow">
          <div className="grid grid-cols-12 gap-2 font-normal text-center py-1 border-b border-black">
            <div className="col-span-1 text-left">Sr.No</div>
            <div className="col-span-4 text-left">Description of Services</div>
            <div className="col-span-1">HSN/SAC</div>
            <div className="col-span-1">GST RATE</div>
            <div className="col-span-1">Qty</div>
            <div className="col-span-1">Rate</div>
            <div className="col-span-1">per</div>
            <div className="col-span-2 text-right">Amount</div>
          </div>
          <div className={`${!isLastPage ? 'border-b-0' : 'border-b border-black'}`}>
            {items.map((item, index) => (
              <div key={item.id} className={`grid grid-cols-12 gap-2 items-start py-2 ${index < items.length - 1 ? 'border-b border-gray-200' : ''}`}>
                <div className="col-span-1 text-center">{item.srNo}</div>
                <div className="col-span-4">
                  <p>{item.description}</p>
                  <p>{item.subscription}</p>
                  <p className="my-2">{item.period}</p>
                  {item.features.map((feature, i) => <p key={i}>{feature}</p>)}
                </div>
                <div className="col-span-1 text-center">{item.hsnSac}</div>
                <div className="col-span-1 text-center">{item.gstRate}</div>
                <div className="col-span-1 text-center">{item.qty}</div>
                <div className="col-span-1 text-center font-bold">{item.rate.toFixed(2)}</div>
                <div className="col-span-1 text-center">{item.per}</div>
                <div className="col-span-2 text-right font-bold">{item.amount.toFixed(2)}</div>
              </div>
            ))}
          </div>
        </div>
        
        {isLastPage && (
          <>
            {/* Summary */}
            <div className="flex justify-end mt-2">
              <div className="w-1/2">
                <div className="flex justify-between border-b border-black pb-1 mb-1">
                  <span>Gross Amount(including Discount)</span>
                  <span className="font-bold">{summary.grossAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>CGST</span>
                  <span>{summary.cgst}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>IGST</span>
                  <span>{summary.igst}</span>
                </div>
                <div className="flex justify-between font-bold border-t border-black pt-1">
                  <span>Total</span>
                  <span>{summary.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between mt-4">
                <div>
                    <p>Amount Chargeable (In Words)</p>
                    <p className="font-bold">{summary.amountInWords}</p>
                </div>
                <p className="font-sans">E. & O.E</p>
            </div>


            {/* Footer */}
            <div className="mt-auto">
                <div className="flex justify-between">
                    <div>
                        <p className="font-medium">Declaration</p>
                        <p className="w-64">{declaration}</p>
                        <br/>
                        <p>{signatory.for}</p>
                        <img src={signatory.signatureUrl} alt="Signature" className="h-16 w-36 my-2 object-contain" />
                        <p>{signatory.title}</p>
                    </div>
                    <div className="text-left">
                        <p>Company's Bank Details</p>
                        <p>A/c Holder’s Name: {bankDetails.holderName}</p>
                        <p>Bank Name: {bankDetails.bankName}</p>
                        <p>A/c No.: {bankDetails.accountNumber}</p>
                        <p>Branch & IFS Code: {bankDetails.branchIfs}</p>
                    </div>
                </div>
            </div>
          </>
        )}
        <div className="text-center text-gray-500 text-xs pt-4">Page {pageNumber} of {totalPages}</div>
      </div>
    </div>
  );
};

export default InvoicePage;
