export interface InvoiceItem {
  id: number;
  srNo: number;
  description: string;
  subscription: string;
  period: string;
  features: string[];
  hsnSac: string;
  gstRate: string;
  qty: number;
  rate: number;
  per: string;
  amount: number;
}

export interface InvoiceData {
  company: {
    name: string;
    logoUrl: string;
    address: string;
    location: string;
    gstin: string;
    state: string;
    cin: string;
    email: string;
    pan: string;
  };
  invoice: {
    number: string;
    date: string;
    modeOfPayment: string;
    reference: string;
    referenceDate: string;
  };
  buyer: {
    name: string;
    address: string;
    country: string;
    state: string;
    stateCode: string;
    email: string;
    id: string;
  };
  items: InvoiceItem[];
  summary: {
    grossAmount: number;
    cgst: string;
    igst: string;
    total: number;
    amountInWords: string;
  };
  bankDetails: {
    holderName: string;
    bankName: string;
    accountNumber: string;
    branchIfs: string;
  };
  declaration: string;
  signatory: {
    for: string;
    title: string;
    signatureUrl: string;
  };
}
